/**
 * 
 */
/*function openTranscript() {
  const options = 'width=700, height=900, top=100, left=500, status=no, menubar=no, toolbar=no, resizable=no'
  window.open('requestTranscript.jsp','_blank ',options)
}

function openEnrollment() {
  const options = 'width=700, height=900, status=no, menubar=no, toolbar=no, resizable=no';
  const leftPosition = (screen.width - 700) / 2; // 화면의 가로 중앙
  console.log("안녕하세요! 이것은 로그 메시지입니다.");
  const topPosition = (screen.height - 900) / 2; // 화면의 세로 중앙
  window.open('requestEnrollmentCertificate.jsp', '_blank', `${options}, left=${leftPosition}, top=${topPosition}`);
}

function openGraduationment() {
  const options = 'width=700, height=900, top=50, left=50, status=no, menubar=no, toolbar=no, resizable=no'
  window.open('requestGraduationCertificate.jsp','_blank',options)
}

*/